import React from 'react';
import logo from './logo.svg';
import './App.css';
import TopBanner from "./components/TopBanner/TopBanner";
import Services from "./components/Services/Services";
import TopNevigation from "./components/TopNevigation/TopNevigation";


function App() {
  return (
    <div>
        <TopNevigation/>
<TopBanner/>
<Services/>
    </div>
  );
}

export default App;
