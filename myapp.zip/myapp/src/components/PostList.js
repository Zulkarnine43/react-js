import React, {Component} from 'react';

class PostList extends Component {

    constructor() {
        super();
        this.state={
            posts:[]
        }
    }
    componentDidMount() {
        axios.get(' ')
            .then(response=>{
                console.log(response)
            })
            .catch(error=>{
                consol.log(error)
            })
    }

    render() {
        return (
            <div>
          <h1>List of posts</h1>
            </div>
    )
        ;
    }
}

export default PostList;