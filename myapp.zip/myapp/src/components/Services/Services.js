import React, {Component, Fragment} from 'react';
import {Container,Row,Col} from "react-bootstrap";
import mobileLogo from  '../../asset/image/mobile.png';
import webLogo from '../../asset/image/monitor.png';
import graphicsLogo from '../../asset/image/puzzle.png';

class Services extends Component {
    render() {
        return (

            <Fragment>
                   <Container className="text-center">
                       <h1 className="serviceMainTitle">MY SERVICES</h1>
                       <Row>

                           <Col lg={4} md={6} sm={12}>
                               <div className="servicecard text-center">
                                   <img src={webLogo} />
                                   <h2 className="serviceName">Web Development</h2>
                                   <p className="serviceDescription">Learn Something Good & Do Something Better</p>
                               </div>
                           </Col >

                           <Col lg={4} md={6} sm={12}>
                               <div  className="servicecard text-center">
                                   <img src={mobileLogo} />
                                   <h2 className="serviceName">Mobile Development</h2>
                                   <p className="serviceDescription">Learn Something Good & Do Something Better</p>
                               </div>

                           </Col>

                           <Col lg={4} md={6} sm={12}>

                               <div  className="servicecard text-center">
                                   <img src={graphicsLogo} />
                                   <h2 className="serviceName">Graphics Development</h2>
                                   <p className="serviceDescription">Learn Something Good & Do Something Better</p>
                               </div>

                           </Col>
                       </Row>
                   </Container>
            </Fragment>

        );
    }
}

export default Services;